import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vol-campaigns-list',
  templateUrl: './vol-campaigns-list.component.html',
  styleUrls: ['./vol-campaigns-list.component.css']
})
export class VolCampaignsListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
