export interface User {
    userId:any;
    userType:any;

}
