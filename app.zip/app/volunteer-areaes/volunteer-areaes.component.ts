import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-volunteer-areaes',
  templateUrl: './volunteer-areaes.component.html',
  styleUrls: ['./volunteer-areaes.component.css']
})
export class VolunteerAreaesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
